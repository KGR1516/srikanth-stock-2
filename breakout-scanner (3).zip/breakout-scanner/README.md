# 📈 Breakout Scanner

> **Daily automated breakout detection for NSE India stocks.**  
> Pulls live market data, screens for breakouts, scores them with a True Quality algorithm, and generates a ready-to-trade Excel report every morning.

---

## 🚀 Quick Start

```bash
# 1. Clone
git clone https://github.com/yourusername/breakout-scanner.git
cd breakout-scanner

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure (optional)
cp .env.example .env
# Edit .env with your settings

# 4. Run once
python -m src.main

# 5. Or schedule daily
python scheduler.py
```

---

## 📁 Project Structure

```
breakout-scanner/
├── config/
│   └── settings.py              # All thresholds & weights
├── src/
│   ├── data/
│   │   └── nse_fetcher.py       # NSE/BSE live data fetcher
│   ├── screener/
│   │   └── breakout_engine.py   # Breakout detection logic
│   ├── scorer/
│   │   └── true_quality.py      # Multi-factor scoring (0-100)
│   ├── reports/
│   │   └── excel_generator.py   # Daily Excel report builder
│   ├── utils/
│   │   └── logger.py            # Structured logging
│   └── main.py                  # Entry point
├── data/
│   ├── input/
│   │   └── watchlist.txt        # Custom stock list (optional)
│   └── output/                  # Generated Excel reports
├── logs/                        # Daily log files
├── tests/                       # Unit tests
├── scheduler.py                 # Daily 8:30 AM cron runner
├── requirements.txt
└── README.md
```

---

## ⚙️ How It Works

### 1. Data Fetch (`src/data/nse_fetcher.py`)
- Fetches NSE bhavcopy or NIFTY 500 snapshot
- Pulls 60-day historical OHLCV via yfinance for each stock
- Calculates volume, turnover, and price data

### 2. Breakout Detection (`src/screener/breakout_engine.py`)
Finds 4 types of setups:
| Type | Criteria |
|------|----------|
| **Strong Fresh** | ≤1% above level, volume ≥5x, RSI < 70 |
| **Fresh** | ≤2% above level, volume ≥5x, RSI < 70 |
| **Solid** | ≤3% above level, volume ≥3x, RSI < 75 |
| **Extended** | >5% above level or RSI ≥ 75 |
| **Failed** | Price fell back below breakout level |

### 3. True Quality Score (`src/scorer/true_quality.py`)

| Dimension | Weight | Description |
|-----------|--------|-------------|
| Entry Checks | 25 | 4-check rule (near level, RSI ok, liquid, not penny) |
| RSI Health | 20 | Lower RSI = more room to run |
| Proximity | 20 | Closer to breakout level = tighter stop |
| Liquidity | 15 | Higher turnover = easier exit |
| Live Status | 15 | Held breakout vs failed vs slipped |
| Volume | 5 | Volume multiple confirmation |
| Catalyst | 5 | Earnings, broker buys, sector themes |

**Penalties:** Loss-making (-8), Failed breakout (-15)

### 4. Action Verdict

| Score | Action | Position Size |
|-------|--------|---------------|
| ≥ 80 | **BUY NOW** | 5-7% of capital |
| 65-79 | **BUY** | 3-5% of capital |
| 50-64 | **WATCH** | Paper trade only |
| 35-49 | **AVOID** | Do not enter |
| < 35 | **SKIP** | Ignore |

### 5. Excel Report (`src/reports/excel_generator.py`)

Generated every morning with 5 sheets:
1. **Master Scan** — All screened stocks ranked by True Score
2. **Actionable Trades** — BUY NOW + BUY with entry/stop/target/R:R
3. **Score Breakdown** — Component-wise scoring for transparency
4. **Pre-Market Checklist** — 10-point tick list before 9:15 AM
5. **Summary** — Daily stats and top performers

---

## 📊 Sample Output

```
DAILY BREAKOUT SUMMARY
================================================================================
📊 Total screened: 151
🟢 BUY NOW: 14
🔵 BUY: 17
🟡 WATCH: 29
🔴 AVOID: 43
⚪ SKIP: 48

🏆 TOP 5 ACTIONABLE TRADES:
 true_rank  symbol   close  breakout_level  pct_above   rsi  volume_x  turnover_cr  final_score action
         1  DEVYANI  118.36          117.80       0.48  61.8      18.0        362.0           90  BUY NOW
         2  BSOFT    311.15          310.00       0.37  60.4       3.0        248.1           87  BUY NOW
         3  SWIGGY   287.34          284.68       0.93  63.3       3.5       2105.8           87  BUY NOW
         4  ROSSTECH 1067.10        1064.00       0.29  61.3       6.6        142.2           87  BUY NOW
         5  IRCTC    513.50          510.90       0.51  57.9       3.4        143.8           85  BUY NOW
```

---

## 🛠️ Configuration

Edit `config/settings.py` or create a `.env` file:

```env
# Screening thresholds
MIN_PRICE=25
MIN_TURNOVER_CR=5
MAX_RSI=70
MAX_PCT_ABOVE=2.0
MIN_VOLUME_X=3.0

# Risk parameters
STOP_PCT=0.015
R_R_T1=2.0
R_R_T2=3.5

# Output
OUTPUT_DIR=./data/output
```

---

## ⏰ Scheduling

### Option A: Python scheduler (runs in background)
```bash
python scheduler.py
# Runs every day at 08:30 AM IST
```

### Option B: Linux/Mac cron
```bash
# Edit crontab
crontab -e

# Add this line for 8:30 AM IST (3:00 AM UTC)
0 3 * * * cd /path/to/breakout-scanner && /usr/bin/python3 -m src.main >> logs/cron.log 2>&1
```

### Option C: Windows Task Scheduler
1. Open Task Scheduler → Create Basic Task
2. Trigger: Daily at 8:30 AM
3. Action: Start a program
4. Program: `python.exe`
5. Arguments: `-m src.main`
6. Start in: `C:\path	oreakout-scanner`

---

## 🧪 Testing

```bash
# Run unit tests
python -m pytest tests/

# Or run specific test
python -m unittest tests.test_screener
```

---

## ⚠️ Disclaimer

This tool is for **educational and research purposes only**. It is **NOT investment advice**.
- Always verify live prices before entering any trade
- Backtest any strategy on historical data before deploying capital
- Consult a SEBI-registered investment advisor
- Past performance does not guarantee future results

---

## 📝 License

MIT License — feel free to fork, modify, and use for personal trading.

---

## 🤝 Contributing

Pull requests welcome! Priority areas:
- [ ] BSE data fetcher
- [ ] Options/F&O breakout scanner
- [ ] Telegram/WhatsApp alert integration
- [ ] Backtesting engine
- [ ] Web dashboard (Streamlit)
