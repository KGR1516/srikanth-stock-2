"""Unit tests for the True Quality scorer."""
import pandas as pd

from src.screener import breakout_engine
from src.scorer import true_quality


def _detected(**kw):
    base = dict(symbol="AAA", close=100.5, prev_close=99, breakout_level=100,
                rsi=58, volume_x=6, turnover_cr=150)
    base.update(kw)
    return breakout_engine.detect_breakouts(pd.DataFrame([base]))


def test_high_quality_scores_well():
    df = true_quality.score(_detected())
    assert df.iloc[0]["final_score"] >= 65
    assert df.iloc[0]["action"] in ("BUY", "BUY NOW")


def test_failed_breakout_penalised():
    df = true_quality.score(_detected(close=98, breakout_level=100))
    assert df.iloc[0]["penalty"] <= -15


def test_score_bounds_and_rank():
    df = true_quality.score(_detected())
    row = df.iloc[0]
    assert 0 <= row["final_score"] <= 100
    assert row["true_rank"] == 1
