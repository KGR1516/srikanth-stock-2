"""Unit tests for the breakout engine."""
import pandas as pd

from src.screener import breakout_engine


def _row(**kw):
    base = dict(close=100, prev_close=99, breakout_level=100, rsi=60,
                volume_x=5, turnover_cr=50)
    base.update(kw)
    return pd.Series(base)


def test_strong_fresh():
    r = _row(close=100.5, breakout_level=100, rsi=60, volume_x=6)
    r["pct_above"] = 0.5
    assert breakout_engine.classify(r) == "Strong Fresh"


def test_solid():
    r = _row(close=102.5, breakout_level=100, rsi=72, volume_x=3)
    r["pct_above"] = 2.5
    assert breakout_engine.classify(r) == "Solid"


def test_extended_by_rsi():
    r = _row(close=100.5, breakout_level=100, rsi=78, volume_x=6)
    r["pct_above"] = 0.5
    assert breakout_engine.classify(r) == "Extended"


def test_failed():
    r = _row(close=98, breakout_level=100)
    r["pct_above"] = -2.0
    assert breakout_engine.classify(r) == "Failed"


def test_detect_and_screen_pipeline():
    df = pd.DataFrame([
        dict(symbol="AAA", close=100.5, prev_close=99, breakout_level=100,
             rsi=60, volume_x=6, turnover_cr=50),
        dict(symbol="PENNY", close=10, prev_close=9, breakout_level=9.9,
             rsi=55, volume_x=6, turnover_cr=1),
    ])
    detected = breakout_engine.detect_breakouts(df)
    assert "setup_type" in detected.columns
    screened = breakout_engine.screen(detected)
    assert "PENNY" not in screened["symbol"].values
    assert "AAA" in screened["symbol"].values
