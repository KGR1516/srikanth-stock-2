"""Daily scheduler — runs the scanner every morning at 8:30 AM."""
import schedule
import time
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.utils.logger import log


def run_scan():
    """Execute the scanner as a subprocess."""
    log.info("Scheduled scan triggered")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "src.main"],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent),
        )
        log.info(f"Scan output:\n{result.stdout}")
        if result.stderr:
            log.error(f"Scan errors:\n{result.stderr}")
    except Exception as e:  # noqa: BLE001
        log.error(f"Scheduled scan failed: {e}")


def main():
    schedule.every().day.at("08:30").do(run_scan)
    log.info("Scheduler started. Runs daily at 08:30 AM IST.")
    log.info("Press Ctrl+C to stop.")
    while True:
        schedule.run_pending()
        time.sleep(60)


if __name__ == "__main__":
    main()
